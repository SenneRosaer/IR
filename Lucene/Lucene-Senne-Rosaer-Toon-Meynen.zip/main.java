import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.File;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import java.util.stream.*;


import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.store.*;
import org.apache.lucene.store.FSDirectory;
import org.xml.sax.*;

import org.json.simple.parser.*;
import org.json.simple.JSONObject;

import java.util.List;

class RetrievalSystem {
    public static void main(String[] args) throws IOException, ParseException {

        Analyzer analyzer = new OwnAnalyzer();
        Path indexPath = Paths.get("indexDirectory");
        if (!Files.exists(indexPath)) {
            Files.createDirectory(indexPath);
            Directory directory = FSDirectory.open(indexPath);
            IndexWriterConfig config = new IndexWriterConfig(analyzer);
            IndexWriter iwriter = new IndexWriter(directory, config);

            JSONParser parser = new JSONParser();
            try {
                //https://stackoverflow.com/questions/1844688/how-to-read-all-files-in-a-folder-from-java
                File folder = new File("SplittedXML");
                File[] listof = folder.listFiles();
                for (File file : listof) {
                    String name = file.getName();
                    List<String> lines = Files.readAllLines(Paths.get("SplittedXML/" + name));
                    Document doc = new Document();

                    for (String line : lines) {
                        JSONObject obj = (JSONObject) parser.parse(line);
                        if (obj.containsKey("Title")) {
                            doc.add(new Field("Title", (String) obj.get("Title"), TextField.TYPE_STORED));
                        }
                        if (obj.containsKey("Body")) {
                            doc.add(new Field("Body", (String) obj.get("Body"), TextField.TYPE_STORED));
                        }
                        if (obj.containsKey("Tags")) {
                            doc.add(new Field("Tags", (String) obj.get("Tags"), TextField.TYPE_STORED));
                        }
                        if (obj.containsKey("CreationDate")) {
                            doc.add(new Field("CreationDate", (String) obj.get("CreationDate"), TextField.TYPE_STORED));
                        }
                    }
                    iwriter.addDocument(doc);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.out.println(iwriter.getDirectory());
            iwriter.close();
        }
        Directory directory = FSDirectory.open(indexPath);


        //basic index search



        QueryParser qparser = new QueryParser("Title", analyzer);
        Query query = qparser.parse("conversion c++ ;from decimal walks");


        DirectoryReader ireader = DirectoryReader.open(directory);
        IndexSearcher isearcher = new IndexSearcher(ireader);
        isearcher.setSimilarity(new BM25Similarity());

        ScoreDoc[] hits = isearcher.search(query, 10).scoreDocs;
        
        Document hitdoc = isearcher.doc(hits[0].doc);
        System.out.println(isearcher.explain(query, hits[0].doc));
        System.out.println(hitdoc.get("Body")+ "\n");
        System.out.println("--------------------------------");
        example();



    }

    public static void example() throws IOException, ParseException {
        Analyzer analyzer = new OwnAnalyzer();

        Path indexPath = Paths.get("indexDirectory");
        Directory directory = FSDirectory.open(indexPath);


        QueryParser qparser = new MultiFieldQueryParser(new String[]{"Title", "Body"}, analyzer);
        Query query = qparser.parse("c++ class.object");


        DirectoryReader ireader = DirectoryReader.open(directory);
        IndexSearcher isearcher = new IndexSearcher(ireader);
        isearcher.setSimilarity(new BM25Similarity());

        ScoreDoc[] hits = isearcher.search(query, 10).scoreDocs;

        Document hitdoc = isearcher.doc(hits[0].doc);
        System.out.println(isearcher.explain(query, hits[0].doc));
        System.out.println(hitdoc.get("Title")+ "\n");
        System.out.println(hitdoc.get("Body")+ "\n");
    }
}
