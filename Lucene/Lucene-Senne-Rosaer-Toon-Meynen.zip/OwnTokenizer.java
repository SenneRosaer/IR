
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.util.CharTokenizer;
import org.apache.lucene.util.AttributeFactory;

public final class OwnTokenizer extends CharTokenizer {
    public OwnTokenizer() {
    }

    protected boolean isTokenChar(int c) {
        return !Character.isWhitespace(c) && c != 59;
    }
}
