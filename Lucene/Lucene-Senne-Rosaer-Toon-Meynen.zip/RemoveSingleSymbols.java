import org.apache.lucene.analysis.FilteringTokenFilter;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;



public class RemoveSingleSymbols extends FilteringTokenFilter {
    private final CharTermAttribute termAtt = (CharTermAttribute)this.addAttribute(CharTermAttribute.class);

    public RemoveSingleSymbols(TokenStream in) {
        super(in);
    }

    protected boolean accept() {
        if (this.termAtt.length() == 1) {
            String tmp =  String.valueOf(this.termAtt.buffer()[0]);
            tmp = tmp.replaceAll("[a-zA-Z]+", "");
            if (tmp != ""){
                return false;
            }
        }
        return true;
    }
}

